/* BrokerBazePodataka.java
 * @autor Maja Jankovic,
 * Univerzitet u Beogradu
 * Fakultet organizacionih nauka 
 * Softverski paterni
 * 08.12.2019.
 */

package RefinedAbstraction;

import Abstraction.BrokerBazePodataka1;

public class BrokerBazePodataka11 extends BrokerBazePodataka1{
    
    @Override
    protected String vratiDrajver(){return "com.mysql.jdbc.Driver";} // Promenljivo!!!
    @Override
    protected String vratiURL(){return "jdbc:mysql://127.0.0.1:3306/nutrition";} // Promenljivo!!!
    @Override
    protected String vratiKorisnickoIme(){return "root";} // Promenljivo!!!
    @Override
    protected String vratiSifru(){return "root";} // Promenljivo!!!
    @Override
    protected String vratiDBMS(){return "MySQL DBMS";} // Promenljivo!!!
      
}
