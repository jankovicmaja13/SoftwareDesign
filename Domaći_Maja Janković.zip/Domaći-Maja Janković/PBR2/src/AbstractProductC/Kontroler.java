/* Kontroler.java
 * @autor Maja Jankovic,
 * Univerzitet u Beogradu
 * Fakultet organizacionih nauka 
 * Softverski paterni
 * 08.12.2019.
 */



package AbstractProductC;

import AbstractProductA.EkranskaForma;
import Abstraction.BrokerBazePodataka;
import ConcreteImplementor.DKPlanIshrane;

public abstract class Kontroler {
    EkranskaForma ef;
    BrokerBazePodataka bbp;
    DKPlanIshrane pi;   // Promenljivo!!!
    String poruka;
         
}
