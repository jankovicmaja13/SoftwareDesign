/* DKPlanIshrane.java
 * @autor Maja Jankovic,
 * Univerzitet u Beogradu
 * Fakultet organizacionih nauka 
 * Softverski paterni
 * 08.12.2019.
 */


package DomainClasses;


import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

// Promenljivo!!!
public class DKPlanIshrane implements Serializable, GeneralDObject {
  
    
    private int SifraPlanaIshrane;
    private String NazivPrograma;
    private String SifraPacijenta;
    private java.util.Date DatumPocetka;
    private java.util.Date DatumKraja;
    private String OpisPrograma;
    private int DnevniUnosKalorija;

    public DKPlanIshrane() {
        SifraPlanaIshrane=0;
        NazivPrograma = "Hrono";
        SifraPacijenta= "00000";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dDatum= new Date();
        DatumPocetka = java.sql.Date.valueOf(sdf.format(dDatum));
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
        Date dDatum1= new Date();
        DatumKraja = java.sql.Date.valueOf(sdf.format(dDatum1));
        OpisPrograma= "/";
        DnevniUnosKalorija=0;
    }
    
    

    public DKPlanIshrane(int SifraPlanaIshrane, String NazivPrograma, String Pacijent, Date DatumPocetka, Date DatumKraja, String OpisPrograma, int DnevniUnosKalorija) {
        this.SifraPlanaIshrane = SifraPlanaIshrane;
        this.NazivPrograma = NazivPrograma;
        this.SifraPacijenta= Pacijent;
        this.DatumPocetka = DatumPocetka;
        this.DatumKraja = DatumKraja;
        this.OpisPrograma = OpisPrograma;
        this.DnevniUnosKalorija = DnevniUnosKalorija;
    }

    
    public int getSifraPlanaIshrane() {
        return SifraPlanaIshrane;
    }

    public void setSifraPlanaIshrane(int SifraPlanaIshrane) {
        this.SifraPlanaIshrane = SifraPlanaIshrane;
    }

    public String getNazivPrograma() {
        return NazivPrograma;
    }

    public void setNazivPrograma(String NazivPrograma) {
        this.NazivPrograma = NazivPrograma;
    }

    public String getSifraPacijenta() {
        return SifraPacijenta;
    }

    public void setSifraPacijenta(String SifraPacijenta) {
        this.SifraPacijenta = SifraPacijenta;
    }
    
    public Date getDatumPocetka() {
        return DatumPocetka;
    }

    public void setDatumPocetka(Date DatumPocetka) {
        this.DatumPocetka = DatumPocetka;
    }

    public Date getDatumKraja() {
        return DatumKraja;
    }

    public void setDatumKraja(Date DatumKraja) {
        this.DatumKraja = DatumKraja;
    }

    public String getOpisPrograma() {
        return OpisPrograma;
    }

    public void setOpisPrograma(String OpisPrograma) {
        this.OpisPrograma = OpisPrograma;
    }

    public int getDnevniUnosKalorija() {
        return DnevniUnosKalorija;
    }

    public void setDnevniUnosKalorija(int DnevniUnosKalorija) {
        this.DnevniUnosKalorija = DnevniUnosKalorija;
    }
    
    
    
    // Primarni kljuc		
    public DKPlanIshrane(int SifraPlanaIshrane)  	
    {   this.SifraPlanaIshrane = SifraPlanaIshrane;
    }

   
    @Override
    public String getNameByColumn(int column)
        { String names[] = {"SifraPlanaIshrane","SifraPacijenta","NazivPrograma","DatumPocetka","DatumKraja","OpisPrograma", "DnevniUnosKalorija"}; 
          return names[column];
        }		
 
    @Override
    public GeneralDObject getNewRecord(ResultSet rs)  throws SQLException
    {return new DKPlanIshrane(rs.getInt("SifraPlanaIshrane"),rs.getString("SifraPacijenta"),rs.getString("NazivPrograma"),rs.getDate("DatumPocetka"),rs.getDate("DatumKraja"),rs.getString("OpisPrograma"), rs.getInt("DnevniUnosKalorija"));} 
    @Override
    public String getAtrValue() {return SifraPlanaIshrane + ", " + (SifraPacijenta == null ? null : "'" + SifraPacijenta + "'")  + ", " + "'" + NazivPrograma + "'" +", " + "'"+ DatumPocetka + "'"+ ", " +"'" + DatumKraja + "'" + ", " + "'" + OpisPrograma + "'" + ", " + DnevniUnosKalorija;}
    @Override
    public String setAtrValue(){return "SifraPlanaIshrane=" + SifraPlanaIshrane + ", " + "SifraPacijenta=" + (SifraPacijenta == null ? null : "'" + SifraPacijenta + "'") + ", "+ "NazivPrograma=" + "'"+NazivPrograma+ "'"+ ", "  + "DatumPocetka=" + "'"+DatumPocetka + "'"+ ", " + "DatumKraja=" + "'" +DatumKraja + "'"+ ", " + "OpisPrograma=" + "'" + OpisPrograma + "'"+ ", " + "DnevniUnosKalorija=" + DnevniUnosKalorija;}
    @Override
    public String getClassName(){return "DKPlanIshrane";}
    @Override
    public String getWhereCondition(){return "SifraPlanaIshrane = " + SifraPlanaIshrane;}
}



    
    
    
