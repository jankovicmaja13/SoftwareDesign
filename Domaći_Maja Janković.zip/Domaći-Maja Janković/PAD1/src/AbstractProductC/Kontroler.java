/* Kontroler.java
 * @autor  Maja Jankovic,
 * Univerzitet u Beogradu
 * Fakultet organizacionih nauka 
 * 08.12.2019.
 */

package AbstractProductC;

import AbstractProductA.EkranskaForma;
import AbstractProductB.BrokerBazePodataka;
import DomainClasses.DKPlanIshrane;

public abstract class Kontroler {
    EkranskaForma ef;
    BrokerBazePodataka bbp;
    DKPlanIshrane pi;   // Promenljivo!!!
    String poruka;
         
}
