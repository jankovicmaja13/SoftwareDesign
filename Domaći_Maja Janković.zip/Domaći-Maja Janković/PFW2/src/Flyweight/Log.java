/* Log.java
 * @autor Maja Jankovic,
 * Univerzitet u Beogradu
 * Fakultet organizacionih nauka 
 * Softverski paterni
 * 08.12.2019.
 */

package Flyweight;

import DomainClasses.GeneralDObject;

public interface Log { // Flyweight
    
    String vratiNazivOperacije();
    String vratiDomenskiObjekat();
    String vratiPoruku();
}
