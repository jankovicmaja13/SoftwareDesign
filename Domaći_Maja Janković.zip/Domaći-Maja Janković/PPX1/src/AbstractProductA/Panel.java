/* Panel.java
 * @autor Maja Jankovic,
 * Univerzitet u Beogradu
 * Fakultet organizacionih nauka 
 * Softverski paterni
 * 08.12.2019.
 */



package AbstractProductA;



import java.awt.event.KeyEvent;
import java.util.Date;
import javax.swing.JTextField;

// Promenljivo!!!
public abstract class Panel extends javax.swing.JPanel{
       
       public abstract String getSifraPlanaIshrane(); // Promenljivo!!!
       public abstract JTextField getSifraPlanaIshrane1(); // Promenljivo!!!
       public abstract String getSifraPacijenta(); // Promenljivo!!!
       public abstract String getNazivPrograma(); // Promenljivo!!!
       public abstract Date getDatumPocetka(); // Promenljivo!!!
       public abstract Date getDatumKraja(); // Promenljivo!!!
       public abstract String getOpisPrograma(); // Promenljivo!!!
       public abstract String getDnevniUnosKalorija(); // Promenljivo!!!
       
       public abstract void setSifraPlanaIshrane(String SifraPlanaIshrane); // Promenljivo!!!
       public abstract void setSifraPacijenta(String SifraPacijenta); // Promenljivo!!!
       public abstract void setNazivPrograma(String NazivPrograma); // Promenljivo!!!
       public abstract void setDatumPocetka(Date DatumPocetka); // Promenljivo!!!
       public abstract void setDatumKraja(Date DatumKraja); // Promenljivo!!!
       public abstract void setOpisPrograma(String OpisPrograma); // Promenljivo!!!
       public abstract void setDnevniUnosKalorija(String DnevniUnosKalorija); // Promenljivo!!!
       
       public abstract void setPoruka(String Poruka);
       
       public abstract javax.swing.JButton getKreiraj(); 
       public abstract javax.swing.JButton getPromeni(); 
       public abstract javax.swing.JButton getObrisi(); 
       public abstract javax.swing.JButton getNadji();
       
       
       
}
