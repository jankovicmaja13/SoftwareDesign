/* ProxyKontroler.java
 * @autor Maja Jankovic,
 * Univerzitet u Beogradu
 * Fakultet organizacionih nauka 
 * Softverski paterni
 * 08.12.2019.
 */

package Proxy;


import RealSubject.Kontroler2;
import Subject.Kontroler;


public class ProxyKontroler extends Kontroler{ // Proxy
       
    protected Kontroler2 kon;
    
    
    public ProxyKontroler(Kontroler2 kon1) {kon=kon1;kon.Povezi(this);}
          
    @Override
    public boolean zapamtiDomenskiObjekat(){ return kon.zapamtiDomenskiObjekat();} 
            
    @Override
    public boolean kreirajDomenskiObjekat(){return kon.kreirajDomenskiObjekat();} 
    
    @Override
    public boolean obrisiDomenskiObjekat(){ kon.prikaziPoruku("��������� �� ������� ����� �������!!!");return false;} 
    
    @Override
    public boolean promeniDomenskiObjekat(){return kon.promeniDomenskiObjekat();} 
    
    @Override
    public boolean nadjiDomenskiObjekat(){return kon.nadjiDomenskiObjekat();} 
    
    @Override
    public void napuniDomenskiObjekatIzGrafickogObjekta(){kon.napuniDomenskiObjekatIzGrafickogObjekta();}

    }     