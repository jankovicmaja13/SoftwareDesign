/* Projektant.java
 * @autor Maja Jankovic,
 * Univerzitet u Beogradu
 * Fakultet organizacionih nauka 
 * Softverski paterni
 * 08.12.2019.
 */


package AbstractFactory;

import Subject.Kontroler;
import AbstractProductA.*;
import AbstractProductB.*;

public interface Projektant {
       EkranskaForma kreirajEkranskuFormu();   
       BrokerBazePodataka kreirajBrokerBazePodataka ();
       Kontroler kreirajKontroler (EkranskaForma ef,BrokerBazePodataka dbbr);   
}
