/* Kontroler1.java
 * @autor Maja Jankovic,
 * Univerzitet u Beogradu
 * Fakultet organizacionih nauka 
 * Softverski paterni
 * 08.12.2019.
 */

package RealSubject;



import AbstractProductA.*;
import AbstractProductB.*;
import Subject.Kontroler;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.SimpleDateFormat;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Timer;
import java.util.TimerTask;
import DomainClasses.DKPlanIshrane;  // Promenljivo


public final class Kontroler1 extends Kontroler{ // RealSubject
   
    
   
    
    public Kontroler1(EkranskaForma ef1,BrokerBazePodataka bbp1){ef=ef1;bbp=bbp1; Povezi(null);}
    
     
    @Override
    public void Povezi(Kontroler kon)
    {
     
     if (kon != null) 
     {   
         javax.swing.JButton Kreiraj = ef.getPanel().getKreiraj();
         javax.swing.JButton Promeni = ef.getPanel().getPromeni();
         javax.swing.JButton Obrisi = ef.getPanel().getObrisi();
         javax.swing.JButton Nadji = ef.getPanel().getNadji();
         Kreiraj.addActionListener( new OsluskivacKreiraj(kon));
         Promeni.addActionListener( new OsluskivacPromeni(kon));
         Obrisi.addActionListener( new OsluskivacObrisi(kon));
         Nadji.addActionListener( new OsluskivacNadji(kon));
        javax.swing.JTextField SifraPlanaIshrane = ef.getPanel().getSifraPlanaIshrane1(); // Promenljivo!!!
     SifraPlanaIshrane.addFocusListener( new OsluskivacNadji1(this));
     }   
    }
    
    // Promenljivo!!!  
    public void napuniDomenskiObjekatIzGrafickogObjekta()   {
       pi= new DKPlanIshrane();
       pi.setSifraPlanaIshrane(getInteger(ef.getPanel().getSifraPlanaIshrane()));
       pi.setSifraPacijenta(ef.getPanel().getSifraPacijenta());
       pi.setDnevniUnosKalorija(getInteger(ef.getPanel().getDnevniUnosKalorija()));
       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
       java.util.Date Datum = java.sql.Date.valueOf(sdf.format(ef.getPanel().getDatumPocetka())); 
       pi.setDatumPocetka(Datum); 
       SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
       java.util.Date Datum1 = java.sql.Date.valueOf(sdf.format(ef.getPanel().getDatumKraja())); 
       pi.setDatumKraja(Datum1); 
       pi.setOpisPrograma(ef.getPanel().getOpisPrograma());
       pi.setNazivPrograma(ef.getPanel().getNazivPrograma());
    
    }

    // Promenljivo!!!
    public void napuniGrafickiObjekatIzDomenskogObjekta(DKPlanIshrane ip){
       ef.getPanel().setSifraPlanaIshrane(Integer.toString(pi.getSifraPlanaIshrane()));
       ef.getPanel().setSifraPacijenta(pi.getSifraPacijenta());
       ef.getPanel().setDnevniUnosKalorija(Integer.toString(pi.getDnevniUnosKalorija()));
       ef.getPanel().setOpisPrograma(pi.getOpisPrograma());
       ef.getPanel().setNazivPrograma(pi.getNazivPrograma());
       ef.getPanel().setDatumPocetka(pi.getDatumPocetka());
       ef.getPanel().setDatumKraja(pi.getDatumKraja());
      
    }

// Promenljivo!!!
public void isprazniGrafickiObjekat(){
 ef.getPanel().setSifraPlanaIshrane("");
 ef.getPanel().setSifraPacijenta("000000");
 ef.getPanel().setNazivPrograma("Hrono");
 ef.getPanel().setOpisPrograma("");
 ef.getPanel().setDatumPocetka(new java.util.Date());
 ef.getPanel().setDatumKraja(new java.util.Date());
 ef.getPanel().setDnevniUnosKalorija("0");
}

public void prikaziPoruku() 
{ ef.getPanel().setPoruka(poruka);
      
  Timer timer = new Timer();
  
  timer.schedule(new TimerTask() {
  @Override
  public void run() {
    ef.getPanel().setPoruka(""); 
  }
}, 3000);
  
}

public int getInteger(String s) {
    int broj = 0;
    try
        {
            if(s != null)
                broj = Integer.parseInt(s);
        }
            catch (NumberFormatException e)
            { broj = 0;}
   
    return broj;
}


 
@Override 
public boolean zapamtiDomenskiObjekat(){ 
    
    bbp.makeConnection();
    boolean signal = bbp.insertRecord(pi);
    if (signal==true) 
        { bbp.commitTransation();
          poruka ="������ �� �������� ���� ���� �������."; // Promenljivo!!!
        }
        else
        { bbp.rollbackTransation();
          poruka ="������ �� ���� �� ������� ���� ���� �������."; // Promenljivo!!!  
        }
    prikaziPoruku();
    bbp.closeConnection();
    return signal; 
       
    }
    
@Override
public boolean kreirajDomenskiObjekat(){
    boolean signal;
    pi= new DKPlanIshrane(); // Promenljivo!!!
    AtomicInteger counter = new AtomicInteger(0);
    
    bbp.makeConnection();
    if (!bbp.getCounter(pi,counter)) return false;
    if (!bbp.increaseCounter(pi,counter)) return false;
          
    pi.setSifraPlanaIshrane(counter.get()); // Promenljivo!!!
    signal = bbp.insertRecord(pi);
    if (signal==true) 
        { bbp.commitTransation();
          napuniGrafickiObjekatIzDomenskogObjekta(pi);
          poruka = "������ �� ������� ���� ���� �������."; // Promenljivo!!!
        }
        else
        { bbp.rollbackTransation();
        isprazniGrafickiObjekat();
        poruka ="������ �� ���� �� ������ ���� ���� �������."; // Promenljivo!!!
        }
    prikaziPoruku();
    bbp.closeConnection();
    return signal;
}

@Override
public boolean obrisiDomenskiObjekat(){
    bbp.makeConnection();
    boolean signal = bbp.deleteRecord(pi);
    if (signal==true) 
        { bbp.commitTransation();
          poruka = "������ je o������ ���� �������."; // Promenljivo!!!
            isprazniGrafickiObjekat();
        }
        else
        { bbp.rollbackTransation();
          poruka = "������ �� ���� �� ������ ���� �������."; // Promenljivo!!!
        }
    prikaziPoruku();
    bbp.closeConnection();
    return signal;   
}

@Override
public boolean promeniDomenskiObjekat(){
    bbp.makeConnection();
    boolean signal = bbp.updateRecord(pi);
    if (signal==true) 
        { bbp.commitTransation();
          poruka = "������ je �������� ���� �������."; // Promenljivo!!!
        }
        else
        { bbp.rollbackTransation();
          isprazniGrafickiObjekat();
          poruka = "������ �� ���� �� ������� ���� �������."; // Promenljivo!!!
        }
    prikaziPoruku();
    bbp.closeConnection();
    return signal;  
}


@Override
public boolean nadjiDomenskiObjekat(){
    boolean signal;
    bbp.makeConnection();
    pi = (DKPlanIshrane)bbp.findRecord(pi); // Promenljivo!!!
    if (pi != null) 
        { napuniGrafickiObjekatIzDomenskogObjekta(pi);
          poruka = "������ je ����� ���� �������."; // Promenljivo!!!
          signal = true;
        }
        else
        { isprazniGrafickiObjekat();
          poruka ="������ �� ���� �� ���� ���� �������."; // Promenljivo!!!
          signal = false;
        }
    prikaziPoruku();
    bbp.closeConnection();
    return signal;   
}

   
}


// Osluskivaci su kod primera za proxy patern klijenti.
class OsluskivacZapamti implements ActionListener
{   Kontroler1 kon;
 
    OsluskivacZapamti(Kontroler1 kon1) {kon = kon1;}
    
@Override
    public void actionPerformed(ActionEvent e) {
         kon.napuniDomenskiObjekatIzGrafickogObjekta();
         kon.zapamtiDomenskiObjekat();
        
    }
}

class OsluskivacKreiraj implements ActionListener
{   Kontroler kon;
 
    OsluskivacKreiraj(Kontroler kon1) {kon = kon1;}
    
@Override
    public void actionPerformed(ActionEvent e) {
         kon.kreirajDomenskiObjekat();
         
        
    }
}

class OsluskivacObrisi implements ActionListener
{   Kontroler kon;
 
    OsluskivacObrisi(Kontroler kon1) {kon = kon1;}
    
@Override
    public void actionPerformed(ActionEvent e) {
         kon.napuniDomenskiObjekatIzGrafickogObjekta();
         kon.obrisiDomenskiObjekat();
        
    }
}

class OsluskivacPromeni implements ActionListener
{   Kontroler kon;
 
    OsluskivacPromeni(Kontroler kon1) {kon = kon1;}
    
@Override
    public void actionPerformed(ActionEvent e) {
         kon.napuniDomenskiObjekatIzGrafickogObjekta();
         kon.promeniDomenskiObjekat();
        
    }
}

class OsluskivacNadji implements ActionListener
{   Kontroler kon;
 
    OsluskivacNadji(Kontroler kon1) {kon = kon1;}
    
@Override
    public void actionPerformed(ActionEvent e) {
         kon.napuniDomenskiObjekatIzGrafickogObjekta();
         kon.nadjiDomenskiObjekat();
        
    }
}

class OsluskivacNadji1 implements FocusListener
{   Kontroler kon;
 
    OsluskivacNadji1(Kontroler kon1) {kon = kon1;}
    

    @Override
    public void focusLost(java.awt.event.FocusEvent e) {
         kon.napuniDomenskiObjekatIzGrafickogObjekta();
         kon.nadjiDomenskiObjekat();
    }

    @Override
    public void focusGained(FocusEvent e) {
        
    }
}

