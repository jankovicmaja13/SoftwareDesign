/* SoftverskiSistem.java
 * @autor Maja Jankovic,
 * Univerzitet u Beogradu
 * Fakultet organizacionih nauka 
 * Softverski paterni
 * 10.11.2019.
 */


package Product;


public interface SoftverskiSistem // Prototype
{
  void prikaziEkranskuFormu(); 
  void zatvoriEkranskuFormu();
  SoftverskiSistem Clone();
}
